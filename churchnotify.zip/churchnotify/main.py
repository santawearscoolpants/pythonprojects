import smtplib
from email.mime.text import MIMEText

def send_email(recipient, subject, body):
    sender = 'elijahnansuuri46@gmail.com'
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = sender
    msg['To'] = recipient

    with smtplib.SMTP('elijahnansuuri46@gmail.com', 587) as server:
        server.starttls()
        server.login(sender, 'SWAGBEAST/0')
        server.sendmail(sender, recipient, msg.as_string())

# Usage
send_email('swagbeastlamar@gmail.com', 'Church Event', 'Join us for the upcoming event...')
