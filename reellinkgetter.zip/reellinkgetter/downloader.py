from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

# Read the Instagram reel links from the text file
with open('reel_links0.txt', 'r') as file:
    reel_links = file.readlines()

# Initialize the WebDriver (this example uses Firefox, adjust if you use Chrome)
driver = webdriver.Firefox()

# Open the download site
download_site = "https://en.savefrom.net/274/download-from-instagram"
driver.get(download_site)

# Iterate over each link
for link in reel_links:
    link = link.strip()  # Remove any leading/trailing whitespace or newlines

    # Locate the input field and paste the link
    input_field = driver.find_element(By.ID, "sf_url")
    input_field.clear()
    input_field.send_keys(link)
    input_field.send_keys(Keys.RETURN)

    # Wait for the user to complete the captcha
    print(f"Please complete the captcha for link: {link}")
    while True:
        try:
            # Check if the download button is visible
            download_button = driver.find_element(By.CLASS_NAME, "def-btn-box")
            if download_button.is_displayed():
                break
        except:
            pass
        time.sleep(2)  # Check every 2 seconds

    # Click the download button
    download_button.click()

    # Wait for the download to complete
    time.sleep(5)  # Adjust the sleep time as needed

# Close the browser
