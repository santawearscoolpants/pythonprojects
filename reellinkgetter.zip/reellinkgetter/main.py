import time
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.firefox.options import Options
from bs4 import BeautifulSoup
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

USERNAME = 'santawearscoolpants'
PASSWORD = 'fuckyouregosss'

if not USERNAME or not PASSWORD:
    logging.error('Instagram username or password not set in environment variables.')
    exit(1)

GECKODRIVER_PATH = '/Users/apple/Desktop/web/geckodriver'
INSTAGRAM_REELS_URL = 'https://www.instagram.com/wealth.enhancers/reels/'

# Initialize the WebDriver with headless option
options = Options()
options.headless = True
service = Service(GECKODRIVER_PATH)
driver = webdriver.Firefox(service=service, options=options)

try:
    logging.info('Opening Instagram login page...')
    driver.get('https://www.instagram.com/accounts/login/')

    # Wait for the login fields to load
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.NAME, 'username')))
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.NAME, 'password')))

    # Enter username and password
    driver.find_element(By.NAME, 'username').send_keys(USERNAME)
    driver.find_element(By.NAME, 'password').send_keys(PASSWORD)

    # Click the login button
    driver.find_element(By.XPATH, '//*[@id="loginForm"]/div/div[3]/button').click()

    # Wait for the main page to load
    WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.TAG_NAME, 'body')))

    # Handle "Save Login Info?" prompt
    try:
        not_now_button = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, '//button[text()="Not Now"]')))
        not_now_button.click()
    except Exception as e:
        logging.warning(f'Failed to click "Not Now" on save login info prompt: {e}')

    # Handle "Turn on Notifications?" prompt
    try:
        not_now_button = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, '//button[text()="Not Now"]')))
        not_now_button.click()
    except Exception as e:
        logging.warning(f'Failed to click "Not Now" on turn on notifications prompt: {e}')

    # Navigate to the Reels page
    logging.info('Navigating to the Reels page...')
    driver.get(INSTAGRAM_REELS_URL)

    # Scroll down the page to load content
    SCROLL_PAUSE_TIME = 2
    reels_per_row = 4
    target_reels = 100
    max_attempts = (target_reels // reels_per_row) * 2

    last_height = driver.execute_script("return document.body.scrollHeight")
    scroll_attempts = 0

    while scroll_attempts < max_attempts:
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(SCROLL_PAUSE_TIME)
        new_height = driver.execute_script("return document.body.scrollHeight")
        if new_height == last_height:
            scroll_attempts += 1
        else:
            scroll_attempts = 0
        last_height = new_height

    # Extract page source
    logging.info('Extracting page source...')
    page_source = driver.page_source
    soup = BeautifulSoup(page_source, 'html.parser')

    # Find all reel links
    reel_links = []
    for a in soup.find_all('a', href=True):
        href = a['href']
        if '/reel/' in href:
            reel_links.append(f'https://www.instagram.com{href}')

    # Keep only the first 100 links
    reel_links = reel_links[:100]

    # Save links to a file
    with open('reel_links.txt', 'w') as f:
        for link in reel_links:
            f.write(f"{link}\n")

    logging.info(f"Extracted {len(reel_links)} reel links and saved to reel_links.txt")

except Exception as e:
    logging.error(f'An error occurred: {e}')

finally:
    # Close the WebDriver
    driver.quit()
    logging.info('WebDriver closed')
