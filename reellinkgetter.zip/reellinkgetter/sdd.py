#service = Service("/Users/apple/Desktop/web/geckodriver")  # Replace with your geckodriver path
#driver.get("https://www.jumia.com.gh/mlp-treasure-hunt/")

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.service import Service
import time

# Initialize the GeckoDriver for Firefox
service = Service("/Users/apple/Desktop/web/geckodriver")  # Replace with your geckodriver path
driver = webdriver.Firefox(service=service)

try:
    # Open the Jumia homepage or the section where products are displayed
    driver.get("https://www.jumia.com.gh/mlp-treasure-hunt/")
    time.sleep(3)  # Allow time for the page to load

    found = False
    section_count = 1

    while not found and section_count <= 50:
        print(f"Checking section {section_count}...")

        # Get all items on the current page
        items = driver.find_elements(By.CLASS_NAME, "info")  # Adjust class name as per site

        # Loop through items to check if any matches our criteria
        for item in items:
            title = item.find_element(By.CLASS_NAME, "name").text
            price = item.find_element(By.CLASS_NAME, "price").text

            # Check if the item title and price match the criteria
            if "Hikers 42\" Smart TV" in title and "21" in price:  # Adjust conditions as needed
                print(f"Found the TV at this URL: {driver.current_url}")
                found = True
                break

        # If not found, go to the next section
        if not found:
            try:
                next_button = driver.find_element(By.CSS_SELECTOR, "a.pagination-next")
                next_button.click()
                time.sleep(3)  # Wait for the next page to load
                section_count += 1
            except:
                print("No more pages to navigate.")
                break

    if not found:
        print("The item was not found within the first 50 sections.")

finally:
    # Close the browser
    driver.quit()
